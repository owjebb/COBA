<?php
session_start();
unset($_SESSION['kepsek']); 
echo "<script>window.location='../';</script>";


?>