
                    <div class="col-md-8">

                    	<div class="card" style="border-radius: 10px; border:2px solid #40c4ff;">
                      <div class="card-header">
                        <strong> <span class="fa fa-edit"></span> Form</strong> User Setting
                      </div>
                      <div class="card-body card-block">
                          <form action="?page=act" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                            <label for="nf-password" class=" form-control-label">Nama Lengkap</label>
                            <input type="text" id="nf-password" name="nama" class="form-control">
                          </div>

                          <div class="form-group">
                          	<label for="nf-email" class=" form-control-label">Username</label>
                          	
                          	<input type="text" id="nf-email" name="user" class="form-control">
                          </div>
                          <div class="form-group">
                          	<label for="nf-password" class=" form-control-label">Password</label>
                          	<input type="text" id="nf-password" name="pass" class="form-control" >
                          </div>
                            <div class="form-group">
                            <label for="nf-password" class=" form-control-label">Foto</label>
                            <input type="file" id="nf-password" name="foto12" class="form-control" >
                          </div>
                       
                      </div>
                      <div class="card-footer">
                        <button type="submit" name="sUserAdmin" class="btn btn-primary">
                          <i class="fa fa-edit"></i> Simpan User
                        </button>
                        <button type="reset" class="btn btn-danger">
                          <i class="fa fa-ban"></i> Reset
                        </button>
                      </div>
                       </form>
                    </div>

                    	
                    </div>