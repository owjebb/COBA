
 <?php
//variabel koneksi
$con = mysqli_connect("localhost","root","","db_jurnal");

if(!$con){
	echo "Koneksi Database Gagal...!!!";
}
?>